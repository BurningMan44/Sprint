Sample configuration files for:

SystemD: sprintd.service
Upstart: sprintd.conf
OpenRC:  sprintd.openrc
         sprintd.openrcconf
CentOS:  sprintd.init
OS X:    org.sprint.sprintd.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
